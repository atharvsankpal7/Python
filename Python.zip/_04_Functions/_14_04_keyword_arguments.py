def func(first, middle, last):
    print(f"The name of the person is : {first} {middle} {last}")


func(first="Atharv", last="Sankpal", middle="Santosh")
