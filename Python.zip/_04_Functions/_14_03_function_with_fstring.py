def func(name, reason):
    
    str = f"Hello, myself {name}, will be unable to join classroom due to {reason}"
    print(str)


func("Atharv", "headache")
func("Shubham", "trip")
func("Aniket", "family function")
