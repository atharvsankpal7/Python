def greetings():
    print("Hello")


def bye():
    print("See you soon")
