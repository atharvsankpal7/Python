# module is a file containing python code

import _18_01_ as ms

ms.greetings()
ms.bye()


# from _18_01_ import greetings
# greetings()

