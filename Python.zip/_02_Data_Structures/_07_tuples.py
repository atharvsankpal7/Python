#tuples are immutable same as string but list however is mutable
tuple1=(1,2,3,4,5,6)
print(tuple1)

tuple1=(3.1,2)
print(tuple1)

'''
tuple1[0]=1
print(tuple1)
#This will not work since tuples can be changed entirely to a new tuple but elements of the existing tuple cannot be changed
#In other words the string and tuples does not support item assingment
'''


