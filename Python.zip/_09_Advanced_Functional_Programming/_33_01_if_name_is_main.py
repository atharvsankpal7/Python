# `__name__` is a special variable given to the module
# when the module is running from it's variable is `__name` variable is assigned with "__main__"

# import _33_02_if_name_is_main

if __name__ == "__main__":
    print("running from module 01")

# print(_33_02_if_name_is_main.__name__)
