import _33_01_if_name_is_main

if __name__ == "__main__":
    print("running from module 02")

print(_33_01_if_name_is_main.__name__)
