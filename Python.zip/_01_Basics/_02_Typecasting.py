f = "5"
g = 10
print(f)
print(g)
print(int(f) + g)
f += "2"
print(f)
