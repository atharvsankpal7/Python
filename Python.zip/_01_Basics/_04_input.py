#default input datatype is string so we have to convert the string to int by typecasting
num1=int(input("Enter the two numbers -->"));

num2=int(input());
print("num1 + num2 = ",num1+num2);
print("num1 - num2 = ",num1-num2);
print("num1 * num2 = ",num1*num2);
print("num1 / num2 = ",num1/num2);
print("num1 / num2 = ",int(num1/num2));
print("num1 % num2 = ",num1%num2);
print("num1 // num2 = ",num1//num2);
print("num1 ** num2 = ",num1**num2);
