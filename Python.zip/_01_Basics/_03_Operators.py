num1=10;
num2=3;
print("num1 + num2 = ",num1+num2);
print("num1 - num2 = ",num1-num2);
print("num1 * num2 = ",num1*num2);
print("num1 / num2 = ",num1/num2);
#print("num1 / num2 = ",int(num1/num2));
print("num1 % num2 = ",num1%num2);
print("num1 // num2 = ",num1//num2);#Floor division operator
print("num1 ** num2 = ",num1**num2);#Exponential operator


#comparison operator
x=2;
y=20;
z=20
print(x==y)
print(x!=y)
print(x==z and y!=x)
print(x==z or y!=x)
print(not(True))