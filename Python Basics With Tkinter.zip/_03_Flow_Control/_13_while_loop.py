i = 0
# while i < 10:
#     print(i)
#     i += 1
# print("Program has been executed")
while True:

    num1 = int(input("Enter the number : "))
    if num1 == 10:
        continue
    elif num1 == 20:
        break
    else:
        print("HELLO")
