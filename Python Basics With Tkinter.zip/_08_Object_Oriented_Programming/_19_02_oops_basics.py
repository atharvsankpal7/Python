from _19_01_Car import Car

car_1 = Car(2004, 232, "Yellow")

car_2 = Car(2022, 324624, "Tango")

car_1.drive()
Car.wheels = 6
car_1.drive()
car_1.wheels = 4
car_1.drive()
car_2.drive()
