def hello():
    print("hello")


variable = hello  # assinging the function to a variable will cause it to copy the address

variable()  # attention on when to use paranthesis or when to not
