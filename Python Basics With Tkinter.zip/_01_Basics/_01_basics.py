a = 4
print(a)
a = 07.4400
print(a)
harry = 2
print(harry)
harry = "This is a string"
print(harry+" via Harry")
e = None
print(e)


num = 100_000_000_000 # underscores will be ignored
print(num)